import React from "react";
import { View, Picker } from "react-native";

export default function PairSelector({ pair, setPair }) {
  const pairs = [
    "EURUSD", "GBPUSD", "USDJPY",
    "EURJPY", "GBPJPY", "EURGBP",
    "EURCHF", "AUDUSD", "USDCAD",
    "NZDUSD", "USDCHF"
  ];

  return (
    <View style={{ marginVertical: 10 }}>
      <Picker selectedValue={pair} onValueChange={setPair}>
        {pairs.map((p) => (
          <Picker.Item key={p} label={p} value={p} />
        ))}
      </Picker>
    </View>
  );
}