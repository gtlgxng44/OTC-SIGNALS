import React from "react";
import { Text, View } from "react-native";

export default function Countdown({ seconds }) {
  return (
    <View style={{ padding: 10 }}>
      <Text style={{ fontSize: 38, fontWeight: "800", color: "red" }}>
        {seconds}s
      </Text>
    </View>
  );
}