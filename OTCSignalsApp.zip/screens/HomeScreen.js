import React, { useEffect, useState } from "react";
import { View, Text, Button, ScrollView } from "react-native";
import Countdown from "../components/Countdown";
import PairSelector from "../components/PairSelector";
import IntervalSelector from "../components/IntervalSelector";

export default function HomeScreen() {
  const [signals, setSignals] = useState([]);
  const [interval, setIntervalValue] = useState(5000);
  const [pair, setPair] = useState("EURUSD");
  const [timer, setTimer] = useState(5);
  const [running, setRunning] = useState(false);

  const tradingWindows = [
    { start: 0, end: 4 },
    { start: 4, end: 7 },
    { start: 7, end: 11 },
    { start: 11, end: 16 },
    { start: 16, end: 20 },
    { start: 20, end: 24 }
  ];

  const checkSession = () => {
    let hour = new Date().getHours();
    return tradingWindows.some(w => hour >= w.start && hour < w.end);
  };

  const createSignal = () => {
    const dirs = ["CALL", "PUT"];
    const conf = Math.floor(Math.random() * 41) + 60;
    const sig = {
      id: Date.now(),
      pair,
      direction: dirs[Math.floor(Math.random() * dirs.length)],
      confidence: conf,
      time: new Date().toLocaleTimeString()
    };
    setSignals([sig, ...signals]);
  };

  useEffect(() => {
    if (!running) return;

    let t = setInterval(() => {
      setTimer((v) => {
        if (v <= 1) {
          if (checkSession()) createSignal();
          return interval / 1000;
        }
        return v - 1;
      });
    }, 1000);

    return () => clearInterval(t);
  }, [running, interval, pair]);

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 28, fontWeight: "bold" }}>OTC Signal Bot</Text>

      <PairSelector pair={pair} setPair={setPair} />
      <IntervalSelector interval={interval} setInterval={setIntervalValue} />

      <Countdown seconds={timer} />

      <Button
        title={running ? "STOP" : "START AUTO SIGNALS"}
        onPress={() => {
          setRunning(!running);
          setTimer(interval / 1000);
        }}
      />

      {!checkSession() && (
        <Text style={{ fontSize: 22, color: "red", fontWeight: "bold", marginTop: 10 }}>
          OUT OF TRADING HOURS
        </Text>
      )}

      <ScrollView style={{ marginTop: 20 }}>
        {signals.map((s) => (
          <View key={s.id} style={{ padding: 10, marginBottom: 10, backgroundColor: "#eee" }}>
            <Text style={{ fontSize: 18 }}>{s.pair}</Text>
            <Text>Direction: {s.direction}</Text>
            <Text>Confidence: {s.confidence}%</Text>
            <Text>{s.time}</Text>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}